let log = function() {
    console.log("=====log======");
}
export default {
    log
};