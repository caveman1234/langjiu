let host = "http://localhost:8080";
let order = {
    list: "/langjiu/list",
    update: "/langjiu/update",
};
export default {
    host,
    order
}