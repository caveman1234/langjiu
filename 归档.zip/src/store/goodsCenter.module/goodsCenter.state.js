let state = {
    goodsData: []
}
export default state;