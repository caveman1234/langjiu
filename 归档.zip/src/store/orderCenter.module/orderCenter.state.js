let state = {
    PurchaseBillsData: []
}
export default state;