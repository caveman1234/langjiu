let state = {
    purchaseCount: 0,
    customerId: '',
    navList: [
        { name: "首页", routeTo: "/Home", hasSelected: true },
        { name: "商品中心", routeTo: "/GoodsCenter", hasSelected: false },
        { name: "订单中心", routeTo: "/OrderCenter", hasSelected: false },
        { name: "账户中心", routeTo: "/AccountCenter", hasSelected: false },
        { name: "消息中心", routeTo: "/MsgCenter", hasSelected: false },
    ]
}
export default state;