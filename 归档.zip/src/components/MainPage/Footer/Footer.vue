<template>
  <div class="footer">
      <div class="footer">
            <div class="container">
                <div class="top">版权所有四川郎酒集团有限责任公司《中华人民共和国电信与信息服务业务经营许可证》蜀ICP备05050669号</div>
                <div class="bottom">成都市天府新区天府大道南延线一段麓湖生态城总部办公基地</div>
            </div>
        </div>
  </div>
</template>
<script>
export default {
  name:'Footer',
  data(){
      return {}
  }
}
</script>
<style lang="scss" scoped>
@import "./Footer.scss";
</style>

