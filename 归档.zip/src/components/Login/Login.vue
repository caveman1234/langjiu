<template>
    <div class="Login">
        <div class="LoginContainer">
            <div class="title">用户登陆</div>
            <el-form :model="loginForm" status-icon :rules="rules" ref="ruleForm2" label-width="100px" size="small" style="width:100%;" class="loginForm">
                <el-form-item label="用户名：" prop="userName">
                    <el-input v-model="loginForm.userName"></el-input>
                </el-form-item>
                <el-form-item label="密码：" prop="passWord">
                    <el-input type="password" v-model="loginForm.passWord"></el-input>
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" @click="submitForm('ruleForm2')">登陆</el-button>
                    <el-button @click="resetForm('ruleForm2')">清空</el-button>
                </el-form-item>
            </el-form>
        </div>
    </div>
</template>
<script>

export default {
    name: 'Login',
    data() {
        let userNameV = (rule, value, callback) => {
            if (!value) {
                return callback(new Error('用户名不能为空'));
            } else {
                callback();
            }
        }
        let pawsswordV = (rule, value, callback) => {
            if (!value) {
                return callback(new Error('密码不能为空'));
            } else {
                callback();
            }
        }
        return {
            loginForm: {
                userName: '',
                passWord: ''
            },
            rules: {
                userName: [
                    { validator: userNameV, message: '用户名不能为空' },
                ],
                passWord: [
                    { validator: pawsswordV, message: '密码不能为空' }
                ]
            }
        }
    },
    methods: {
        submitForm(formName) {
            let _this = this;
            this.$refs[formName].validate((valid) => {
                if (valid) {
                    this.$store.commit('setCustomerId', '123');
                    let paramsWrap = {
                        params:{
                            customerId:'2b6c6970-2464-4040-9db5-e314ff67eb9d'
                        }
                    };
                    // _this.$http.get('/ocm-web/api/base/prodline/get-mgr-list',paramsWrap);
                    _this.$http({
                        method: 'post',
                        url: '/ocm-web/api/account/login',
                        data: _this.loginForm
                    });
                } else {
                    console.log('error submit!!');
                    return false;
                }
            });
        },
        resetForm(formName) {
            this.$refs[formName].resetFields();
        },
    }
}
</script>
<style lang="scss" scoped>
@import "./Login.scss";
</style>

