<template>
    <div class="AccountMgr">
        AccountMgr
    </div>
</template>
<script>
export default {
    name: 'AccountMgr'
}
</script>
<style lang="scss" scoped>
@import './AccountMgr';
</style>

